BOT_TOKEN = "7765561530:AAEek8zz2W73AgGhFkIGN2boPrQKLO8W-IM"
CONTACTS_FILE = "contacts.json"
HISTORY_DIR = "history"
LANG = "ru_RU.UTF-8"
MUSIC = {
    "start": "assets/o-privet.mp3",
    "exit": "assets/da-poshiol-ty-nakhui.mp3"
}
